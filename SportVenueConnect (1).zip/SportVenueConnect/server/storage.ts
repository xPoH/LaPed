import { 
  type User, type InsertUser,
  type Venue, type InsertVenue,
  type Booking, type InsertBooking,
  type SparringMatch, type InsertSparringMatch,
  type SparringParticipant, type InsertSparringParticipant,
  type Community, type InsertCommunity,
  type CommunityEvent, type InsertCommunityEvent,
  type CommunityMember, type InsertCommunityMember,
  type PartnerRegistration, type InsertPartnerRegistration,
  users, venues, bookings, sparringMatches, sparringParticipants,
  communities, communityEvents, communityMembers, partnerRegistrations
} from "@shared/schema";
import { db } from "./db";
import { eq, and, sql, desc } from "drizzle-orm";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Venues
  getVenues(): Promise<Venue[]>;
  getVenueById(id: number): Promise<Venue | undefined>;
  getVenuesBySport(sport: string): Promise<Venue[]>;
  getVenuesByCity(city: string): Promise<Venue[]>;
  createVenue(venue: InsertVenue): Promise<Venue>;

  // Bookings
  getBookingsByVenue(venueId: number): Promise<Booking[]>;
  getBookingsByDateAndVenue(venueId: number, bookingDate: string): Promise<Booking[]>;
  createBooking(booking: InsertBooking): Promise<Booking>;

  // Sparring Matches
  getSparringMatches(): Promise<SparringMatch[]>;
  getSparringMatchById(id: number): Promise<SparringMatch | undefined>;
  getSparringMatchesBySport(sport: string): Promise<SparringMatch[]>;
  createSparringMatch(match: InsertSparringMatch): Promise<SparringMatch>;
  updateSparringMatchPlayerCount(id: number, currentPlayers: number): Promise<void>;

  // Sparring Participants
  getSparringParticipants(sparringMatchId: number): Promise<SparringParticipant[]>;
  createSparringParticipant(participant: InsertSparringParticipant): Promise<SparringParticipant>;

  // Communities
  getCommunities(): Promise<Community[]>;
  getCommunityById(id: number): Promise<Community | undefined>;
  getCommunitiesBySport(sport: string): Promise<Community[]>;
  createCommunity(community: InsertCommunity): Promise<Community>;
  updateCommunityMemberCount(id: number, memberCount: number): Promise<void>;

  // Community Events
  getCommunityEvents(communityId: number): Promise<CommunityEvent[]>;
  createCommunityEvent(event: InsertCommunityEvent): Promise<CommunityEvent>;

  // Community Members
  getCommunityMembers(communityId: number): Promise<CommunityMember[]>;
  createCommunityMember(member: InsertCommunityMember): Promise<CommunityMember>;

  // Partner Registrations
  createPartnerRegistration(registration: InsertPartnerRegistration): Promise<PartnerRegistration>;
  getPartnerRegistrations(): Promise<PartnerRegistration[]>;
}

export class DatabaseStorage implements IStorage {
  // Users
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  // Venues
  async getVenues(): Promise<Venue[]> {
    return await db.select().from(venues);
  }

  async getVenueById(id: number): Promise<Venue | undefined> {
    const [venue] = await db.select().from(venues).where(eq(venues.id, id));
    return venue || undefined;
  }

  async getVenuesBySport(sport: string): Promise<Venue[]> {
    return await db.select().from(venues).where(eq(venues.sport, sport));
  }

  async getVenuesByCity(city: string): Promise<Venue[]> {
    return await db.select().from(venues).where(eq(venues.city, city));
  }

  async createVenue(venue: InsertVenue): Promise<Venue> {
    const [newVenue] = await db.insert(venues).values(venue).returning();
    return newVenue;
  }

  // Bookings
  async getBookingsByVenue(venueId: number): Promise<Booking[]> {
    return await db.select().from(bookings).where(eq(bookings.venueId, venueId));
  }

  async getBookingsByDateAndVenue(venueId: number, bookingDate: string): Promise<Booking[]> {
    return await db.select().from(bookings).where(
      and(eq(bookings.venueId, venueId), eq(bookings.bookingDate, bookingDate))
    );
  }

  async createBooking(booking: InsertBooking): Promise<Booking> {
    const [newBooking] = await db.insert(bookings).values(booking).returning();
    return newBooking;
  }

  // Sparring Matches
  async getSparringMatches(): Promise<SparringMatch[]> {
    return await db.select().from(sparringMatches).orderBy(desc(sparringMatches.id));
  }

  async getSparringMatchById(id: number): Promise<SparringMatch | undefined> {
    const [match] = await db.select().from(sparringMatches).where(eq(sparringMatches.id, id));
    return match || undefined;
  }

  async getSparringMatchesBySport(sport: string): Promise<SparringMatch[]> {
    return await db.select().from(sparringMatches).where(eq(sparringMatches.sport, sport));
  }

  async createSparringMatch(match: InsertSparringMatch): Promise<SparringMatch> {
    const [newMatch] = await db.insert(sparringMatches).values(match).returning();
    return newMatch;
  }

  async updateSparringMatchPlayerCount(id: number, currentPlayers: number): Promise<void> {
    await db.update(sparringMatches)
      .set({ currentPlayers })
      .where(eq(sparringMatches.id, id));
  }

  // Sparring Participants
  async getSparringParticipants(sparringMatchId: number): Promise<SparringParticipant[]> {
    return await db.select().from(sparringParticipants)
      .where(eq(sparringParticipants.sparringMatchId, sparringMatchId));
  }

  async createSparringParticipant(participant: InsertSparringParticipant): Promise<SparringParticipant> {
    const [newParticipant] = await db.insert(sparringParticipants).values(participant).returning();
    return newParticipant;
  }

  // Communities
  async getCommunities(): Promise<Community[]> {
    return await db.select().from(communities).orderBy(desc(communities.memberCount));
  }

  async getCommunityById(id: number): Promise<Community | undefined> {
    const [community] = await db.select().from(communities).where(eq(communities.id, id));
    return community || undefined;
  }

  async getCommunitiesBySport(sport: string): Promise<Community[]> {
    return await db.select().from(communities).where(eq(communities.sport, sport));
  }

  async createCommunity(community: InsertCommunity): Promise<Community> {
    const [newCommunity] = await db.insert(communities).values(community).returning();
    return newCommunity;
  }

  async updateCommunityMemberCount(id: number, memberCount: number): Promise<void> {
    await db.update(communities)
      .set({ memberCount })
      .where(eq(communities.id, id));
  }

  // Community Events
  async getCommunityEvents(communityId: number): Promise<CommunityEvent[]> {
    return await db.select().from(communityEvents)
      .where(eq(communityEvents.communityId, communityId));
  }

  async createCommunityEvent(event: InsertCommunityEvent): Promise<CommunityEvent> {
    const [newEvent] = await db.insert(communityEvents).values(event).returning();
    return newEvent;
  }

  // Community Members
  async getCommunityMembers(communityId: number): Promise<CommunityMember[]> {
    return await db.select().from(communityMembers)
      .where(eq(communityMembers.communityId, communityId));
  }

  async createCommunityMember(member: InsertCommunityMember): Promise<CommunityMember> {
    const [newMember] = await db.insert(communityMembers).values(member).returning();
    return newMember;
  }

  // Partner Registrations
  async createPartnerRegistration(registration: InsertPartnerRegistration): Promise<PartnerRegistration> {
    const [newRegistration] = await db.insert(partnerRegistrations).values(registration).returning();
    return newRegistration;
  }

  async getPartnerRegistrations(): Promise<PartnerRegistration[]> {
    return await db.select().from(partnerRegistrations).orderBy(desc(partnerRegistrations.submittedAt));
  }
}

export const storage = new DatabaseStorage();

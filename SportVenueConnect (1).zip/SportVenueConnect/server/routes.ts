import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertBookingSchema, insertSparringParticipantSchema, insertCommunityMemberSchema, insertPartnerRegistrationSchema } from "@shared/schema";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // Venues API
  app.get("/api/venues", async (req, res) => {
    try {
      const { sport, city } = req.query;
      
      let venues;
      if (sport && typeof sport === 'string') {
        venues = await storage.getVenuesBySport(sport);
      } else if (city && typeof city === 'string') {
        venues = await storage.getVenuesByCity(city);
      } else {
        venues = await storage.getVenues();
      }
      
      res.json(venues);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch venues" });
    }
  });

  app.get("/api/venues/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const venue = await storage.getVenueById(id);
      
      if (!venue) {
        return res.status(404).json({ error: "Venue not found" });
      }
      
      res.json(venue);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch venue" });
    }
  });

  // Bookings API
  app.get("/api/bookings/venue/:venueId", async (req, res) => {
    try {
      const venueId = parseInt(req.params.venueId);
      const { date } = req.query;
      
      let bookings;
      if (date && typeof date === 'string') {
        bookings = await storage.getBookingsByDateAndVenue(venueId, date);
      } else {
        bookings = await storage.getBookingsByVenue(venueId);
      }
      
      res.json(bookings);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch bookings" });
    }
  });

  app.post("/api/bookings", async (req, res) => {
    try {
      const validatedData = insertBookingSchema.parse(req.body);
      const booking = await storage.createBooking(validatedData);
      res.status(201).json(booking);
    } catch (error) {
      res.status(400).json({ error: "Invalid booking data" });
    }
  });

  // Sparring Matches API
  app.get("/api/sparring", async (req, res) => {
    try {
      const { sport } = req.query;
      
      let matches;
      if (sport && typeof sport === 'string') {
        matches = await storage.getSparringMatchesBySport(sport);
      } else {
        matches = await storage.getSparringMatches();
      }
      
      res.json(matches);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch sparring matches" });
    }
  });

  app.get("/api/sparring/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const match = await storage.getSparringMatchById(id);
      
      if (!match) {
        return res.status(404).json({ error: "Sparring match not found" });
      }
      
      res.json(match);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch sparring match" });
    }
  });

  app.post("/api/sparring/:id/join", async (req, res) => {
    try {
      const matchId = parseInt(req.params.id);
      const match = await storage.getSparringMatchById(matchId);
      
      if (!match) {
        return res.status(404).json({ error: "Sparring match not found" });
      }
      
      if (match.currentPlayers >= match.maxPlayers) {
        return res.status(400).json({ error: "Match is full" });
      }
      
      const validatedData = insertSparringParticipantSchema.parse({
        ...req.body,
        sparringMatchId: matchId
      });
      
      const participant = await storage.createSparringParticipant(validatedData);
      await storage.updateSparringMatchPlayerCount(matchId, match.currentPlayers + 1);
      
      res.status(201).json(participant);
    } catch (error) {
      res.status(400).json({ error: "Failed to join sparring match" });
    }
  });

  // Communities API
  app.get("/api/communities", async (req, res) => {
    try {
      const { sport } = req.query;
      
      let communities;
      if (sport && typeof sport === 'string') {
        communities = await storage.getCommunitiesBySport(sport);
      } else {
        communities = await storage.getCommunities();
      }
      
      res.json(communities);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch communities" });
    }
  });

  app.get("/api/communities/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const community = await storage.getCommunityById(id);
      
      if (!community) {
        return res.status(404).json({ error: "Community not found" });
      }
      
      const events = await storage.getCommunityEvents(id);
      
      res.json({ ...community, events });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch community" });
    }
  });

  app.post("/api/communities/:id/join", async (req, res) => {
    try {
      const communityId = parseInt(req.params.id);
      const community = await storage.getCommunityById(communityId);
      
      if (!community) {
        return res.status(404).json({ error: "Community not found" });
      }
      
      const validatedData = insertCommunityMemberSchema.parse({
        ...req.body,
        communityId
      });
      
      const member = await storage.createCommunityMember(validatedData);
      await storage.updateCommunityMemberCount(communityId, community.memberCount + 1);
      
      res.status(201).json(member);
    } catch (error) {
      res.status(400).json({ error: "Failed to join community" });
    }
  });

  // Partner Registration API
  app.post("/api/partner-registration", async (req, res) => {
    try {
      const validatedData = insertPartnerRegistrationSchema.parse(req.body);
      const registration = await storage.createPartnerRegistration(validatedData);
      res.status(201).json(registration);
    } catch (error) {
      res.status(400).json({ error: "Invalid registration data" });
    }
  });

  return httpServer;
}

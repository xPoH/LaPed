import { db } from "./db";
import { venues, sparringMatches, communities, communityEvents } from "@shared/schema";

async function seed() {
  console.log("🌱 Seeding database...");

  // Seed Venues
  const venueData = [
    {
      name: "GOR Futsal Arena Jakarta",
      sport: "Futsal",
      location: "Jl. Sudirman No. 123, Jakarta Pusat",
      city: "Jakarta",
      pricePerHour: 150000,
      rating: "4.8",
      image: "/attached_assets/generated_images/futsal-court_modern_indoor_fu_2836e6db.png",
      facilities: ["Parkir Luas", "Kantin", "Toilet Bersih", "Ruang Ganti", "AC"],
      description: "Lapangan futsal indoor dengan lantai vinyl premium dan pencahayaan LED profesional. Dilengkapi AC dan sound system.",
      openHour: "06:00",
      closeHour: "23:00",
      contactPhone: "0812-3456-7890",
      googleMapsUrl: "https://maps.google.com"
    },
    {
      name: "Arena Badminton Sempurna",
      sport: "Badminton",
      location: "Jl. Asia Afrika No. 45, Bandung",
      city: "Bandung",
      pricePerHour: 80000,
      rating: "4.6",
      image: "/attached_assets/generated_images/badminton-court_professiona_fb28c48e.png",
      facilities: ["Karpet Premium", "Shuttle Service", "Kantin", "Locker"],
      description: "7 lapangan badminton dengan standar internasional, karpet Yonex dan net profesional.",
      openHour: "07:00",
      closeHour: "22:00",
      contactPhone: "0813-9876-5432",
      googleMapsUrl: "https://maps.google.com"
    },
    {
      name: "Basket Center Surabaya",
      sport: "Basket",
      location: "Jl. Raya Darmo No. 88, Surabaya",
      city: "Surabaya",
      pricePerHour: 200000,
      rating: "4.9",
      image: "/attached_assets/generated_images/basketball-court_modern_ind_59ddacbd.png",
      facilities: ["Indoor AC", "Tribun Penonton", "Papan Skor Elektronik", "Sound System"],
      description: "Lapangan basket indoor dengan lantai parket standar DBL, ring profesional Spalding.",
      openHour: "08:00",
      closeHour: "23:00",
      contactPhone: "0815-2468-1357",
      googleMapsUrl: "https://maps.google.com"
    }
  ];

  await db.insert(venues).values(venueData);
  console.log("✅ Venues seeded");

  // Seed Sparring Matches
  const sparringData = [
    {
      sport: "Futsal",
      title: "Sparing Futsal Sore - Pemain Pemula Welcome",
      location: "GOR Futsal Arena Jakarta",
      city: "Jakarta",
      matchDate: "2024-12-05",
      matchTime: "17:00",
      skillLevel: "Pemula",
      currentPlayers: 4,
      maxPlayers: 10,
      costPerPerson: 25000,
      description: "Butuh 6 pemain lagi untuk full team. Suasana santai tapi tetap kompetitif!",
      organizerName: "Andi Prasetyo",
      organizerPhone: "0821-5555-1234",
      image: "/attached_assets/generated_images/futsal-court_modern_indoor_fu_2836e6db.png"
    },
    {
      sport: "Badminton",
      title: "Doubles Match - Level Intermediate",
      location: "Arena Badminton Sempurna",
      city: "Bandung",
      matchDate: "2024-12-06",
      matchTime: "19:00",
      skillLevel: "Menengah",
      currentPlayers: 2,
      maxPlayers: 4,
      costPerPerson: 30000,
      description: "Cari 1 pasangan doubles lagi untuk main bareng. Level menengah ke atas ya!",
      organizerName: "Budi Santoso",
      organizerPhone: "0822-6666-5678",
      image: "/attached_assets/generated_images/badminton-court_professiona_fb28c48e.png"
    }
  ];

  await db.insert(sparringMatches).values(sparringData);
  console.log("✅ Sparring matches seeded");

  // Seed Communities
  const communityData = [
    {
      name: "Jakarta Futsal United",
      sport: "Futsal",
      city: "Jakarta",
      memberCount: 247,
      description: "Komunitas futsal terbesar di Jakarta dengan member dari berbagai kalangan. Kami rutin mengadakan turnamen bulanan dan gathering.",
      founded: "2019",
      image: "/attached_assets/generated_images/futsal-team_group_of_enthusi_c9a9e8a5.png",
      contactPerson: "Reza Firmansyah",
      contactPhone: "0856-7777-8888",
      socialMedia: { instagram: "@jktfutsalunited", whatsapp: "0856-7777-8888" },
      gallery: [
        "/attached_assets/generated_images/futsal-court_modern_indoor_fu_2836e6db.png",
        "/attached_assets/generated_images/futsal-team_group_of_enthusi_c9a9e8a5.png"
      ]
    },
    {
      name: "Bandung Badminton Club",
      sport: "Badminton",
      city: "Bandung",
      memberCount: 156,
      description: "Komunitas badminton yang fokus pada pengembangan skill dan networking. Latihan rutin setiap Rabu & Sabtu.",
      founded: "2020",
      image: "/attached_assets/generated_images/badminton-court_professiona_fb28c48e.png",
      contactPerson: "Siti Nurhaliza",
      contactPhone: "0857-8888-9999",
      socialMedia: { instagram: "@bdgbadminton", whatsapp: "0857-8888-9999" },
      gallery: []
    }
  ];

  await db.insert(communities).values(communityData);
  console.log("✅ Communities seeded");

  // Seed Community Events
  const eventData = [
    {
      communityId: 1,
      title: "Turnamen Futsal Ramadan Cup 2024",
      eventDate: "2024-12-15",
      location: "GOR Futsal Arena Jakarta",
      description: "Turnamen futsal antar klub se-Jabodetabek. Hadiah total 10 juta rupiah!"
    },
    {
      communityId: 2,
      title: "Latihan Bersama & Coaching Clinic",
      eventDate: "2024-12-10",
      location: "Arena Badminton Sempurna",
      description: "Sesi latihan bersama dengan coach berpengalaman. Gratis untuk member!"
    }
  ];

  await db.insert(communityEvents).values(eventData);
  console.log("✅ Community events seeded");

  console.log("🎉 Seeding completed!");
  process.exit(0);
}

seed().catch((error) => {
  console.error("❌ Seeding failed:", error);
  process.exit(1);
});

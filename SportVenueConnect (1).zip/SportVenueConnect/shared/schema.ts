import { pgTable, text, serial, integer, timestamp, boolean, decimal, json, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { sql } from "drizzle-orm";

// Users (keep existing for auth)
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Venues Table
export const venues = pgTable("venues", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  sport: text("sport").notNull(),
  location: text("location").notNull(),
  city: text("city").notNull(),
  pricePerHour: integer("price_per_hour").notNull(),
  rating: decimal("rating", { precision: 2, scale: 1 }).default("4.5"),
  image: text("image").notNull(),
  facilities: text("facilities").array().notNull(),
  description: text("description").notNull(),
  openHour: text("open_hour").notNull().default("06:00"),
  closeHour: text("close_hour").notNull().default("23:00"),
  contactPhone: text("contact_phone").notNull(),
  googleMapsUrl: text("google_maps_url"),
});

export const insertVenueSchema = createInsertSchema(venues).omit({
  id: true,
});
export type InsertVenue = z.infer<typeof insertVenueSchema>;
export type Venue = typeof venues.$inferSelect;

// Bookings Table
export const bookings = pgTable("bookings", {
  id: serial("id").primaryKey(),
  venueId: integer("venue_id").notNull().references(() => venues.id),
  userName: text("user_name").notNull(),
  userPhone: text("user_phone").notNull(),
  bookingDate: text("booking_date").notNull(),
  timeSlot: text("time_slot").notNull(),
  duration: integer("duration").notNull(),
  totalPrice: integer("total_price").notNull(),
  status: text("status").notNull().default("pending"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertBookingSchema = createInsertSchema(bookings).omit({
  id: true,
  createdAt: true,
});
export type InsertBooking = z.infer<typeof insertBookingSchema>;
export type Booking = typeof bookings.$inferSelect;

// Sparring Matches Table
export const sparringMatches = pgTable("sparring_matches", {
  id: serial("id").primaryKey(),
  sport: text("sport").notNull(),
  title: text("title").notNull(),
  location: text("location").notNull(),
  city: text("city").notNull(),
  matchDate: text("match_date").notNull(),
  matchTime: text("match_time").notNull(),
  skillLevel: text("skill_level").notNull(),
  currentPlayers: integer("current_players").notNull().default(0),
  maxPlayers: integer("max_players").notNull(),
  costPerPerson: integer("cost_per_person").notNull(),
  description: text("description").notNull(),
  organizerName: text("organizer_name").notNull(),
  organizerPhone: text("organizer_phone").notNull(),
  image: text("image").notNull(),
});

export const insertSparringMatchSchema = createInsertSchema(sparringMatches).omit({
  id: true,
});
export type InsertSparringMatch = z.infer<typeof insertSparringMatchSchema>;
export type SparringMatch = typeof sparringMatches.$inferSelect;

// Sparring Participants Table
export const sparringParticipants = pgTable("sparring_participants", {
  id: serial("id").primaryKey(),
  sparringMatchId: integer("sparring_match_id").notNull().references(() => sparringMatches.id),
  userName: text("user_name").notNull(),
  userPhone: text("user_phone").notNull(),
  joinedAt: timestamp("joined_at").defaultNow().notNull(),
});

export const insertSparringParticipantSchema = createInsertSchema(sparringParticipants).omit({
  id: true,
  joinedAt: true,
});
export type InsertSparringParticipant = z.infer<typeof insertSparringParticipantSchema>;
export type SparringParticipant = typeof sparringParticipants.$inferSelect;

// Communities Table
export const communities = pgTable("communities", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  sport: text("sport").notNull(),
  city: text("city").notNull(),
  memberCount: integer("member_count").notNull().default(0),
  description: text("description").notNull(),
  founded: text("founded").notNull(),
  image: text("image").notNull(),
  contactPerson: text("contact_person").notNull(),
  contactPhone: text("contact_phone").notNull(),
  socialMedia: json("social_media").$type<{ instagram?: string; whatsapp?: string }>(),
  gallery: text("gallery").array().notNull().default([]),
});

export const insertCommunitySchema = createInsertSchema(communities).omit({
  id: true,
});
export type InsertCommunity = z.infer<typeof insertCommunitySchema>;
export type Community = typeof communities.$inferSelect;

// Community Events Table
export const communityEvents = pgTable("community_events", {
  id: serial("id").primaryKey(),
  communityId: integer("community_id").notNull().references(() => communities.id),
  title: text("title").notNull(),
  eventDate: text("event_date").notNull(),
  location: text("location").notNull(),
  description: text("description").notNull(),
});

export const insertCommunityEventSchema = createInsertSchema(communityEvents).omit({
  id: true,
});
export type InsertCommunityEvent = z.infer<typeof insertCommunityEventSchema>;
export type CommunityEvent = typeof communityEvents.$inferSelect;

// Community Members Table
export const communityMembers = pgTable("community_members", {
  id: serial("id").primaryKey(),
  communityId: integer("community_id").notNull().references(() => communities.id),
  userName: text("user_name").notNull(),
  userPhone: text("user_phone").notNull(),
  joinedAt: timestamp("joined_at").defaultNow().notNull(),
});

export const insertCommunityMemberSchema = createInsertSchema(communityMembers).omit({
  id: true,
  joinedAt: true,
});
export type InsertCommunityMember = z.infer<typeof insertCommunityMemberSchema>;
export type CommunityMember = typeof communityMembers.$inferSelect;

// Partner Registrations Table
export const partnerRegistrations = pgTable("partner_registrations", {
  id: serial("id").primaryKey(),
  venueName: text("venue_name").notNull(),
  sportCategories: text("sport_categories").array().notNull(),
  description: text("description").notNull(),
  address: text("address").notNull(),
  city: text("city").notNull(),
  postalCode: text("postal_code").notNull(),
  googleMapsUrl: text("google_maps_url"),
  contactPhone: text("contact_phone").notNull(),
  status: text("status").notNull().default("pending"),
  submittedAt: timestamp("submitted_at").defaultNow().notNull(),
});

export const insertPartnerRegistrationSchema = createInsertSchema(partnerRegistrations).omit({
  id: true,
  submittedAt: true,
});
export type InsertPartnerRegistration = z.infer<typeof insertPartnerRegistrationSchema>;
export type PartnerRegistration = typeof partnerRegistrations.$inferSelect;

import { useState } from "react";
import { 
  MapPin, 
  Star, 
  Wifi, 
  Car, 
  Utensils,
  Heart
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { motion, AnimatePresence } from "framer-motion";
import { toast } from "@/hooks/use-toast";
import { Link } from "wouter";

interface VenueCardProps {
  title: string;
  location: string;
  price: string;
  rating: number;
  reviews: number;
  image: string;
  type: string;
  features?: string[];
  distance?: string;
  index?: number;
  id?: number;
}

export function VenueCard({ 
  title, 
  location, 
  price, 
  rating, 
  reviews, 
  image,
  type,
  features = ["wifi", "parking"],
  distance = "1.2 km",
  index = 0,
  id = 1
}: VenueCardProps) {
  const [isFavorite, setIsFavorite] = useState(false);

  const toggleFavorite = (e: React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();
    setIsFavorite(!isFavorite);
    toast({
      title: !isFavorite ? "Disimpan ke Favorit" : "Dihapus dari Favorit",
      description: `${title} ${!isFavorite ? "telah ditambahkan" : "telah dihapus"} dari daftar favoritmu.`,
      variant: !isFavorite ? "default" : "destructive",
    });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.4, delay: index * 0.1 }}
      className="h-full"
    >
      <Link href={`/venue/${id}`}>
        <Card className="group cursor-pointer overflow-hidden border-none shadow-md hover:shadow-xl transition-all duration-300 bg-white dark:bg-slate-900 h-full flex flex-col">
          <div className="relative h-48 overflow-hidden">
            <img 
              src={image} 
              alt={title} 
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
            />
            
            {/* Type Badge */}
            <div className="absolute top-3 left-3">
              <Badge className="bg-white/90 text-slate-900 hover:bg-white font-semibold backdrop-blur-sm shadow-sm">
                {type}
              </Badge>
            </div>

            {/* Favorite Button */}
            <button 
              onClick={toggleFavorite}
              className="absolute top-3 right-3 p-2 rounded-full bg-white/20 backdrop-blur-md hover:bg-white/40 transition-all shadow-sm group/heart z-10"
            >
              <Heart 
                className={`w-5 h-5 transition-all duration-300 ${isFavorite ? 'fill-red-500 text-red-500 scale-110' : 'text-white group-hover/heart:scale-110'}`} 
              />
            </button>

            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent p-4 translate-y-2 group-hover:translate-y-0 transition-transform duration-300">
              <div className="flex items-center text-white text-sm font-medium opacity-0 group-hover:opacity-100 transition-opacity duration-300 delay-75">
                <MapPin className="w-3 h-3 mr-1 text-primary" />
                {distance} dari lokasi anda
              </div>
            </div>
          </div>

          <CardHeader className="p-4 pb-2">
            <div className="flex justify-between items-start mb-1">
              <h3 className="font-heading font-bold text-lg leading-tight group-hover:text-primary transition-colors line-clamp-1">
                {title}
              </h3>
              <div className="flex items-center bg-yellow-50 px-2 py-1 rounded-md border border-yellow-100 shrink-0 ml-2">
                <Star className="w-3 h-3 text-yellow-500 fill-yellow-500 mr-1" />
                <span className="text-xs font-bold text-yellow-700">{rating}</span>
              </div>
            </div>
            <p className="text-muted-foreground text-sm line-clamp-1 flex items-center">
              {location}
            </p>
          </CardHeader>

          <CardContent className="p-4 pt-2 flex-1">
            <div className="flex gap-2 mb-4 flex-wrap">
              {features.map((feature, i) => (
                <div key={i} className="flex items-center text-[10px] font-medium text-slate-600 bg-slate-100 px-2 py-1 rounded-full uppercase tracking-wider">
                  {feature === "wifi" && <Wifi className="w-3 h-3 mr-1" />}
                  {feature === "parking" && <Car className="w-3 h-3 mr-1" />}
                  {feature === "canteen" && <Utensils className="w-3 h-3 mr-1" />}
                  {feature}
                </div>
              ))}
            </div>
            
            <div className="flex items-baseline gap-1">
              <span className="text-primary font-bold text-lg">{price}</span>
              <span className="text-muted-foreground text-xs">/ jam</span>
            </div>
          </CardContent>

          <CardFooter className="p-4 pt-0 mt-auto">
            <Button className="w-full bg-slate-900 hover:bg-slate-800 text-white dark:bg-white dark:text-slate-900 group-hover:translate-y-0 transition-all relative overflow-hidden">
              <span className="relative z-10">Booking Sekarang</span>
              <div className="absolute inset-0 bg-primary translate-y-full group-hover:translate-y-0 transition-transform duration-300 z-0" />
            </Button>
          </CardFooter>
        </Card>
      </Link>
    </motion.div>
  );
}
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { 
  MapPin, 
  Users, 
  Search, 
  Menu,
  UserCircle,
  Briefcase
} from "lucide-react";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from "@/components/ui/sheet";

export function Navbar() {
  const [location] = useLocation();

  const NavLink = ({ href, children, icon: Icon }: { href: string, children: React.ReactNode, icon?: any }) => {
    const isActive = location === href;
    return (
      <Link href={href}>
        <div className={`flex items-center gap-2 px-3 py-2 rounded-lg transition-colors cursor-pointer ${isActive ? 'bg-primary/10 text-primary font-semibold' : 'text-muted-foreground hover:text-primary hover:bg-primary/5'}`}>
          {Icon && <Icon className="w-4 h-4" />}
          {children}
        </div>
      </Link>
    );
  };

  return (
    <nav className="sticky top-0 z-50 w-full border-b bg-background/80 backdrop-blur-md">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        {/* Logo */}
        <Link href="/">
          <div className="flex items-center gap-2 cursor-pointer">
            <div className="w-8 h-8 rounded-lg bg-brand-gradient flex items-center justify-center text-white font-bold font-heading text-xl">
              L
            </div>
            <span className="text-xl font-bold font-heading tracking-tight">
              LaPed<span className="text-primary">.</span>
            </span>
          </div>
        </Link>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-1">
          <NavLink href="/" icon={MapPin}>Cari Lapangan</NavLink>
          <NavLink href="/explore" icon={Search}>Jelajah</NavLink>
          <NavLink href="/community" icon={Users}>Komunitas</NavLink>
          <NavLink href="/partner-register" icon={Briefcase}>Jadi Mitra</NavLink>
        </div>

        {/* User Actions */}
        <div className="hidden md:flex items-center gap-4">
          <Button variant="ghost" size="sm" className="text-muted-foreground">
            Masuk
          </Button>
          <Button size="sm" className="bg-brand-gradient border-0 hover:opacity-90 transition-opacity shadow-lg shadow-primary/20">
            Daftar
          </Button>
        </div>

        {/* Mobile Menu */}
        <div className="md:hidden">
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon">
                <Menu className="w-5 h-5" />
              </Button>
            </SheetTrigger>
            <SheetContent>
              <div className="flex flex-col gap-4 mt-8">
                <NavLink href="/" icon={MapPin}>Cari Lapangan</NavLink>
                <NavLink href="/explore" icon={Search}>Jelajah</NavLink>
                <NavLink href="/community" icon={Users}>Komunitas & Sparring</NavLink>
                <NavLink href="/partner-register" icon={Briefcase}>Jadi Mitra</NavLink>
                <hr className="my-2" />
                <Button variant="outline" className="w-full">Masuk</Button>
                <Button className="w-full bg-brand-gradient">Daftar</Button>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </nav>
  );
}
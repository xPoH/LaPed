import { Link } from "wouter";
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Search, 
  MapPin, 
  Calendar, 
  Dumbbell,
  ChevronRight
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

// Assets
import imgFutsal from "@assets/generated_images/energetic_indoor_futsal_match_action_shot.png";
import imgBasketball from "@assets/generated_images/urban_basketball_court_at_twilight.png";
import imgTeam from "@assets/generated_images/happy_sports_team_high-fiving.png";

const heroImages = [imgFutsal, imgBasketball, imgTeam];
const heroWords = ["Lawan Tanding", "Komunitas", "Jadwal Main"];

export function Hero() {
  const [currentImage, setCurrentImage] = useState(0);
  const [currentWord, setCurrentWord] = useState(0);

  // Carousel Effect
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentImage((prev) => (prev + 1) % heroImages.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  // Word Rotate Effect
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentWord((prev) => (prev + 1) % heroWords.length);
    }, 3000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="relative w-full min-h-[650px] flex items-center justify-center overflow-hidden bg-slate-900">
      
      {/* Background Slider */}
      <AnimatePresence mode="wait">
        <motion.div 
          key={currentImage}
          initial={{ opacity: 0, scale: 1.1 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 1.5 }}
          className="absolute inset-0 z-0"
        >
          <img 
            src={heroImages[currentImage]} 
            alt="Background" 
            className="w-full h-full object-cover opacity-50"
          />
        </motion.div>
      </AnimatePresence>
      
      <div className="absolute inset-0 bg-gradient-to-b from-slate-900/60 via-slate-900/50 to-background z-0" />
      <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 mix-blend-overlay z-0"></div>

      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 text-center mt-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="max-w-4xl mx-auto"
        >
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2 }}
            className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 border border-white/20 backdrop-blur-md text-blue-200 text-sm font-medium mb-6"
          >
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-blue-500"></span>
            </span>
            Platform Olahraga #1 di Indonesia
          </motion.div>

          <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold font-heading text-white mb-6 leading-tight tracking-tight">
            Temukan Lapangan & <br/>
            <span className="relative inline-block min-w-[300px] text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-400">
              <AnimatePresence mode="wait">
                <motion.span
                  key={currentWord}
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  exit={{ y: -20, opacity: 0 }}
                  transition={{ duration: 0.3 }}
                  className="absolute left-0 right-0 mx-auto"
                >
                  {heroWords[currentWord]}
                </motion.span>
              </AnimatePresence>
              <span className="invisible">{heroWords[0]}</span> {/* Spacer */}
            </span>
          </h1>
          
          <p className="text-lg text-gray-200 mb-10 max-w-2xl mx-auto leading-relaxed">
            Satu aplikasi untuk semua kebutuhan olahragamu. Booking lapangan, cari lawan sparring, hingga gabung turnamen.
          </p>

          {/* Search Box */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="bg-white/10 backdrop-blur-xl p-2 md:p-3 rounded-3xl border border-white/20 shadow-2xl max-w-4xl mx-auto hover:bg-white/15 transition-colors duration-300"
          >
            <div className="grid grid-cols-1 md:grid-cols-12 gap-2">
              <div className="md:col-span-4 relative group">
                <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-300 group-focus-within:text-primary transition-colors" />
                <Input 
                  placeholder="Lokasi (mis. Tebet)" 
                  className="pl-11 bg-white/5 border-transparent h-14 text-white placeholder:text-white/60 focus-visible:ring-2 focus-visible:ring-primary/50 focus-visible:bg-white/10 transition-all rounded-2xl text-base"
                />
              </div>
              
              <div className="md:col-span-3 relative group">
                <Dumbbell className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-300 group-focus-within:text-primary transition-colors z-10" />
                <select className="w-full h-14 pl-11 pr-4 rounded-2xl bg-white/5 border-transparent text-white/90 text-base focus:outline-none focus:bg-white/10 focus:ring-2 focus:ring-primary/50 transition-all appearance-none cursor-pointer">
                  <option value="" className="bg-slate-800">Pilih Olahraga</option>
                  <option value="futsal" className="bg-slate-800">Futsal</option>
                  <option value="badminton" className="bg-slate-800">Badminton</option>
                  <option value="basketball" className="bg-slate-800">Basket</option>
                  <option value="tennis" className="bg-slate-800">Tenis</option>
                </select>
              </div>

              <div className="md:col-span-3 relative group">
                <Calendar className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-300 group-focus-within:text-primary transition-colors" />
                <Input 
                  type="date"
                  className="pl-11 bg-white/5 border-transparent h-14 text-white placeholder:text-white/60 focus-visible:ring-2 focus-visible:ring-primary/50 focus-visible:bg-white/10 transition-all rounded-2xl text-base [color-scheme:dark]"
                />
              </div>

              <Link href="/explore" className="md:col-span-2">
                <Button className="w-full h-14 bg-primary hover:bg-blue-600 text-white rounded-2xl font-bold text-base shadow-lg shadow-blue-500/30 transition-all hover:scale-105 active:scale-95">
                  Cari <ChevronRight className="ml-1 w-5 h-5" />
                </Button>
              </Link>
            </div>
          </motion.div>

          {/* Popular Tags */}
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.6 }}
            className="mt-6 flex flex-wrap justify-center gap-3 text-sm text-white/60"
          >
            <span>Populer:</span>
            {['Futsal Malam', 'Badminton Tebet', 'Basket Senayan', 'Mini Soccer'].map((tag) => (
              <Link key={tag} href="/explore">
                <span className="px-3 py-1 rounded-full bg-white/5 border border-white/10 hover:bg-white/10 hover:border-white/30 cursor-pointer transition-all">
                  {tag}
                </span>
              </Link>
            ))}
          </motion.div>

        </motion.div>
      </div>
    </div>
  );
}
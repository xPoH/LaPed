import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Link, useLocation } from "wouter";
import { ChevronLeft, Building2, MapPin, DollarSign, Upload, CheckCircle2 } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { motion } from "framer-motion";

export default function PartnerRegister() {
  const [, setLocation] = useLocation();
  const [step, setStep] = useState(1);

  const handleNext = () => {
    if (step < 3) {
      setStep(step + 1);
      window.scrollTo(0, 0);
    } else {
      toast({
        title: "Pendaftaran Berhasil! 🎉",
        description: "Tim kami akan memverifikasi data GOR Anda dalam 1x24 jam.",
      });
      setTimeout(() => setLocation("/"), 2000);
    }
  };

  const handleBack = () => {
    if (step > 1) setStep(step - 1);
    else setLocation("/");
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 pt-6 pb-20">
      <div className="container mx-auto px-4 max-w-2xl">
        <Button 
          variant="ghost" 
          size="sm" 
          className="mb-6 pl-0 hover:bg-transparent hover:text-primary"
          onClick={handleBack}
        >
          <ChevronLeft className="w-4 h-4 mr-2" /> {step === 1 ? "Kembali ke Beranda" : "Sebelumnya"}
        </Button>

        <div className="mb-8 text-center">
          <h1 className="text-3xl font-heading font-bold text-slate-900 dark:text-white mb-2">
            Gabung Mitra LaPed
          </h1>
          <p className="text-muted-foreground">
            Kelola lapangan olahraga Anda dengan sistem booking modern & jangkau ribuan pelanggan baru.
          </p>
        </div>

        {/* Progress Indicator */}
        <div className="flex items-center justify-center gap-4 mb-8">
          {[1, 2, 3].map((i) => (
            <div key={i} className="flex items-center">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm border-2 transition-colors ${
                step >= i 
                  ? "bg-primary border-primary text-white" 
                  : "bg-transparent border-slate-200 text-slate-400"
              }`}>
                {step > i ? <CheckCircle2 className="w-5 h-5" /> : i}
              </div>
              {i < 3 && (
                <div className={`w-12 h-0.5 mx-2 ${step > i ? "bg-primary" : "bg-slate-200"}`} />
              )}
            </div>
          ))}
        </div>

        <motion.div
          key={step}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          className="bg-white dark:bg-slate-900 rounded-2xl shadow-sm border p-6 md:p-8"
        >
          {step === 1 && (
            <div className="space-y-6">
              <h2 className="text-xl font-bold flex items-center gap-2">
                <Building2 className="w-5 h-5 text-primary" /> Informasi Venue
              </h2>
              
              <div className="space-y-2">
                <Label>Nama GOR / Lapangan</Label>
                <Input placeholder="Contoh: GOR Sejahtera Abadi" />
              </div>

              <div className="space-y-2">
                <Label>Kategori Olahraga</Label>
                <div className="grid grid-cols-2 gap-3">
                  {['Futsal', 'Badminton', 'Basket', 'Voli', 'Tenis', 'Mini Soccer'].map((sport) => (
                    <div key={sport} className="flex items-center space-x-2 border p-3 rounded-lg hover:bg-slate-50 cursor-pointer">
                      <Checkbox id={`sport-${sport}`} />
                      <label
                        htmlFor={`sport-${sport}`}
                        className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer w-full"
                      >
                        {sport}
                      </label>
                    </div>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <Label>Deskripsi Singkat</Label>
                <Textarea placeholder="Ceritakan tentang fasilitas dan keunggulan lapangan Anda..." />
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-6">
              <h2 className="text-xl font-bold flex items-center gap-2">
                <MapPin className="w-5 h-5 text-primary" /> Lokasi & Kontak
              </h2>
              
              <div className="space-y-2">
                <Label>Alamat Lengkap</Label>
                <Textarea placeholder="Jl. Sudirman No. 123, Jakarta Pusat..." />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Kota / Kabupaten</Label>
                  <Input placeholder="Jakarta Pusat" />
                </div>
                <div className="space-y-2">
                  <Label>Kode Pos</Label>
                  <Input placeholder="10220" />
                </div>
              </div>

              <div className="space-y-2">
                <Label>Link Google Maps (Opsional)</Label>
                <Input placeholder="https://maps.app.goo.gl/..." />
              </div>

              <div className="space-y-2">
                <Label>Nomor WhatsApp Pengelola</Label>
                <Input type="tel" placeholder="0812-3456-7890" />
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-6">
              <h2 className="text-xl font-bold flex items-center gap-2">
                <Upload className="w-5 h-5 text-primary" /> Foto & Verifikasi
              </h2>
              
              <div className="space-y-2">
                <Label>Foto Utama Venue</Label>
                <div className="border-2 border-dashed border-slate-200 rounded-xl h-40 flex flex-col items-center justify-center text-slate-400 cursor-pointer hover:bg-slate-50 hover:border-primary/50 transition-colors">
                  <Upload className="w-8 h-8 mb-2" />
                  <span className="text-sm">Klik untuk upload atau drag & drop</span>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Foto Fasilitas Lain (Kantin, Parkir, Toilet)</Label>
                <div className="grid grid-cols-3 gap-3">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="border-2 border-dashed border-slate-200 rounded-lg h-24 flex items-center justify-center text-slate-400 cursor-pointer hover:bg-slate-50">
                      <span className="text-xs">+ Foto</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-blue-50 p-4 rounded-lg text-sm text-blue-800 flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 shrink-0 mt-0.5" />
                <p>
                  Dengan mendaftar, Anda menyetujui Syarat & Ketentuan Mitra LaPed. Tim kami akan menghubungi Anda untuk verifikasi final.
                </p>
              </div>
            </div>
          )}

          <div className="mt-8 pt-6 border-t flex justify-end">
            <Button 
              onClick={handleNext} 
              className="bg-brand-gradient px-8"
            >
              {step === 3 ? "Kirim Pendaftaran" : "Lanjut"}
            </Button>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
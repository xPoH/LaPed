import { Hero } from "@/components/home/hero";
import { VenueCard } from "@/components/venue/venue-card";
import { SparringCard } from "@/components/social/sparring-card";
import { Button } from "@/components/ui/button";
import { ArrowRight, Trophy, Users, Building2, Handshake } from "lucide-react";
import { motion } from "framer-motion";
import { Link } from "wouter";

// Import assets
import venueFutsal from "@assets/generated_images/modern_indoor_futsal_court_empty.png";
import venueBadminton from "@assets/generated_images/indoor_badminton_court_empty.png";
import venueBasketball from "@assets/generated_images/urban_basketball_court_at_twilight.png";

export default function Home() {
  return (
    <div className="min-h-screen bg-slate-50 dark:bg-black">
      <Hero />
      
      {/* Featured Venues Section */}
      <section className="py-16 container mx-auto px-4">
        <div className="flex justify-between items-end mb-8">
          <div>
            <h2 className="text-3xl font-heading font-bold text-slate-900 dark:text-white mb-2">
              Lapangan Terpopuler
            </h2>
            <p className="text-muted-foreground">Booking lapangan terbaik pilihan komunitas.</p>
          </div>
          <Link href="/explore">
            <Button variant="ghost" className="hidden md:flex text-primary hover:text-primary/80 hover:bg-primary/10">
              Lihat Semua <ArrowRight className="ml-2 w-4 h-4" />
            </Button>
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <VenueCard 
            title="Arena Futsal Champions"
            location="Kemang, Jakarta Selatan"
            price="Rp 150.000"
            rating={4.8}
            reviews={128}
            image={venueFutsal}
            type="Futsal"
            features={["wifi", "parking", "canteen"]}
            id={1}
          />
          <VenueCard 
            title="GOR Badminton Sejahtera"
            location="Tebet, Jakarta Selatan"
            price="Rp 80.000"
            rating={4.5}
            reviews={85}
            image={venueBadminton}
            type="Badminton"
            features={["parking", "canteen"]}
            id={2}
          />
          <VenueCard 
            title="Skyline Basketball Court"
            location="Senayan, Jakarta Pusat"
            price="Rp 200.000"
            rating={4.9}
            reviews={210}
            image={venueBasketball}
            type="Basketball"
            features={["wifi", "parking"]}
            id={3}
          />
        </div>
        
        <div className="mt-6 text-center md:hidden">
          <Link href="/explore">
            <Button variant="outline" className="w-full">Lihat Semua Lapangan</Button>
          </Link>
        </div>
      </section>

      {/* Partners Section */}
      <section className="py-10 bg-white dark:bg-slate-900/50 border-y border-slate-100 dark:border-slate-800 overflow-hidden">
        <div className="container mx-auto px-4">
           <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-bold text-slate-500 uppercase tracking-wider flex items-center gap-2">
                <Handshake className="w-5 h-5" /> Mitra Resmi Kami
              </h3>
              <Link href="/explore">
                <Button variant="link" className="text-slate-500">Gabung Jadi Mitra</Button>
              </Link>
           </div>
           
           <div className="flex flex-wrap justify-center md:justify-start gap-8 md:gap-12 opacity-70 grayscale hover:grayscale-0 transition-all duration-500">
             {['Adidas', 'Nike', 'Puma', 'Yonex', 'Specs', 'Ortuseight'].map((brand, i) => (
               <Link key={i} href={`/partner/${i}`}>
                 <div className="cursor-pointer group">
                    <div className="text-2xl font-bold text-slate-300 group-hover:text-slate-800 dark:group-hover:text-white transition-colors">
                      {brand}
                    </div>
                 </div>
               </Link>
             ))}
           </div>
        </div>
      </section>

      {/* Sparring Finder Section */}
      <section className="py-16 bg-white dark:bg-slate-900">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row gap-12 items-center">
            <div className="md:w-1/3">
              <Badge className="mb-4 bg-purple-100 text-purple-700 hover:bg-purple-200 border-none">
                Komunitas & Sparing
              </Badge>
              <h2 className="text-3xl md:text-4xl font-heading font-bold mb-4 leading-tight">
                Cari Lawan, <br/>
                <span className="text-brand-gradient">Tambah Teman.</span>
              </h2>
              <p className="text-muted-foreground mb-6">
                Jangan main sendirian! Temukan tim atau lawan tanding yang selevel denganmu di fitur Sparring Finder.
              </p>
              <Link href="/community">
                <Button className="bg-slate-900 text-white hover:bg-slate-800 px-8 h-12 rounded-xl shadow-lg shadow-slate-900/20">
                  Cari Lawan Sparing
                </Button>
              </Link>
            </div>

            <div className="md:w-2/3 grid grid-cols-1 md:grid-cols-2 gap-4 w-full">
              <SparringCard 
                teamName="FC Barcelona Fans Indo"
                sport="Futsal"
                level="Intermediate"
                date="Sab 12"
                time="19:00"
                location="Arena Futsal Champions"
                needed={2}
                id={1}
              />
              <SparringCard 
                teamName="Badminton Happy Club"
                sport="Badminton"
                level="Beginner"
                date="Min 13"
                time="09:00"
                location="GOR Sejahtera"
                needed={1}
                id={2}
              />
              <SparringCard 
                teamName="Street Ballers JKT"
                sport="Basketball"
                level="Advanced"
                date="Jum 11"
                time="20:00"
                location="Skyline Court"
                needed={3}
                id={3}
              />
              <Link href="/community">
                <div className="bg-brand-gradient rounded-xl p-6 flex flex-col items-center justify-center text-white text-center h-full cursor-pointer hover:shadow-lg transition-shadow">
                  <h3 className="font-bold text-xl mb-2">50+ Sparing</h3>
                  <p className="text-white/80 text-sm mb-4">Tersedia minggu ini di sekitarmu</p>
                  <Button variant="secondary" size="sm" className="bg-white/20 text-white hover:bg-white/30 border-0">
                    Lihat Semua
                  </Button>
                </div>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Value Proposition / Features */}
      <section className="py-20 container mx-auto px-4">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <h2 className="text-3xl font-heading font-bold mb-4">Kenapa Pilih LaPed?</h2>
          <p className="text-muted-foreground">
            Platform olahraga terlengkap yang mengerti kebutuhanmu, dari booking hingga komunitas.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {[
            {
              icon: Building2,
              title: "Booking Mudah & Cepat",
              desc: "Cek jadwal real-time dan booking lapangan favoritmu tanpa perlu telepon sana-sini."
            },
            {
              icon: Users,
              title: "Komunitas Aktif",
              desc: "Gabung dengan ribuan pecinta olahraga, buat event, dan bangun jaringanmu."
            },
            {
              icon: Trophy,
              title: "Turnamen & Event",
              desc: "Ikuti berbagai turnamen seru dan event olahraga yang diadakan komunitas partner."
            }
          ].map((feature, i) => (
            <motion.div 
              key={i}
              whileHover={{ y: -5 }}
              className="bg-white dark:bg-slate-900 p-8 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-800 text-center"
            >
              <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center mx-auto mb-6 text-primary">
                <feature.icon className="w-8 h-8" />
              </div>
              <h3 className="font-heading font-bold text-xl mb-3">{feature.title}</h3>
              <p className="text-muted-foreground leading-relaxed">
                {feature.desc}
              </p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Join Partner CTA Section */}
      <section className="py-20 bg-slate-900 text-white overflow-hidden relative">
        <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-10 mix-blend-overlay"></div>
        <div className="absolute top-0 right-0 w-96 h-96 bg-purple-500/20 rounded-full blur-3xl -translate-y-1/2 translate-x-1/3"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-blue-500/20 rounded-full blur-3xl translate-y-1/2 -translate-x-1/3"></div>
        
        <div className="container mx-auto px-4 relative z-10">
          <div className="flex flex-col md:flex-row items-center justify-between gap-12">
            <div className="md:w-1/2">
              <Badge className="mb-4 bg-white/10 text-white border-white/20 backdrop-blur-md">
                Untuk Pemilik GOR & Lapangan
              </Badge>
              <h2 className="text-4xl md:text-5xl font-heading font-bold mb-6 leading-tight">
                Kelola Bisnis Lapanganmu <br/> 
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-400">Lebih Efisien.</span>
              </h2>
              <ul className="space-y-4 mb-8">
                {[
                  "Sistem Booking Online Otomatis",
                  "Laporan Keuangan Real-time",
                  "Promosi ke Ribuan Komunitas Olahraga"
                ].map((item, i) => (
                  <li key={i} className="flex items-center gap-3 text-lg text-slate-300">
                    <div className="w-6 h-6 rounded-full bg-green-500/20 text-green-400 flex items-center justify-center">
                      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                    </div>
                    {item}
                  </li>
                ))}
              </ul>
              <Link href="/partner-register">
                <Button className="h-14 px-8 bg-white text-slate-900 hover:bg-slate-100 font-bold text-lg rounded-xl">
                  Gabung Jadi Mitra Sekarang
                </Button>
              </Link>
            </div>
            
            <div className="md:w-1/2 relative">
              <div className="relative bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl p-6 transform rotate-2 hover:rotate-0 transition-transform duration-500">
                <div className="flex items-center gap-4 mb-6 border-b border-white/10 pb-4">
                  <div className="w-12 h-12 rounded-full bg-brand-gradient flex items-center justify-center text-white font-bold">
                    L
                  </div>
                  <div>
                    <div className="font-bold text-lg">Dashboard Mitra</div>
                    <div className="text-sm text-slate-400">Statistik Minggu Ini</div>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4 mb-6">
                  <div className="bg-white/5 rounded-xl p-4">
                    <div className="text-sm text-slate-400 mb-1">Total Booking</div>
                    <div className="text-2xl font-bold text-white">142</div>
                    <div className="text-xs text-green-400 mt-1">↑ 12% dari minggu lalu</div>
                  </div>
                  <div className="bg-white/5 rounded-xl p-4">
                    <div className="text-sm text-slate-400 mb-1">Pendapatan</div>
                    <div className="text-2xl font-bold text-white">Rp 8.5jt</div>
                    <div className="text-xs text-green-400 mt-1">↑ 8% dari minggu lalu</div>
                  </div>
                </div>
                <div className="h-32 bg-white/5 rounded-xl flex items-end justify-between p-4 gap-2">
                  {[40, 65, 45, 80, 55, 90, 75].map((h, i) => (
                    <div key={i} className="w-full bg-brand-gradient rounded-t-sm opacity-80" style={{ height: `${h}%` }}></div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* Footer Simple */}
      <footer className="bg-slate-900 text-white py-12">
        <div className="container mx-auto px-4 text-center">
          <div className="flex items-center justify-center gap-2 mb-6">
            <div className="w-8 h-8 rounded-lg bg-brand-gradient flex items-center justify-center text-white font-bold font-heading text-xl">
              L
            </div>
            <span className="text-xl font-bold font-heading tracking-tight">
              LaPed<span className="text-primary">.</span>
            </span>
          </div>
          <p className="text-slate-400 mb-8 max-w-md mx-auto">
            Platform ekosistem olahraga #1 di Indonesia. Temukan lapangan, teman main, dan komunitasmu disini.
          </p>
          <div className="text-sm text-slate-600">
            © 2024 LaPed Indonesia. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
}

function Badge({ className, children, variant }: { className?: string, children: React.ReactNode, variant?: string }) {
  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${className}`}>
      {children}
    </span>
  );
}
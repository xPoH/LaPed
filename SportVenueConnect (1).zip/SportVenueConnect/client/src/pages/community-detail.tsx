import { useRoute, Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Users, 
  Trophy, 
  Calendar, 
  MapPin, 
  ChevronLeft,
  ExternalLink
} from "lucide-react";
import { toast } from "@/hooks/use-toast";

export default function CommunityDetail() {
  const [, params] = useRoute("/community/:id");

  const community = {
    id: params?.id,
    name: "Badminton Happy Club Jakarta",
    category: "Badminton",
    members: 1240,
    location: "Jakarta Selatan",
    description: "Komunitas pecinta badminton untuk semua level, dari pemula sampai pro. Kita main rutin setiap Selasa & Jumat malam. Visi kami adalah menyehatkan masyarakat lewat tepok bulu!",
    nextEvent: {
      title: "Turnamen Internal BHC Cup 2025",
      date: "20 Okt 2025",
      location: "GOR Sejahtera"
    }
  };

  const handleJoin = () => {
    toast({
      title: "Berhasil Bergabung! 🎉",
      description: `Selamat datang di komunitas ${community.name}!`,
    });
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 pb-20 pt-6">
      <div className="container mx-auto px-4 max-w-4xl">
        <Link href="/community">
          <Button variant="ghost" size="sm" className="mb-4 pl-0 hover:bg-transparent hover:text-primary">
            <ChevronLeft className="w-4 h-4 mr-2" /> Kembali ke Komunitas
          </Button>
        </Link>

        <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-sm border overflow-hidden mb-6">
          <div className="h-48 bg-gradient-to-r from-purple-600 to-pink-600 relative">
            <div className="absolute bottom-0 left-0 w-full bg-gradient-to-t from-black/60 to-transparent p-6">
              <div className="flex items-end gap-4">
                <div className="w-20 h-20 rounded-2xl bg-white p-1 shadow-lg mb-[-10px]">
                  <div className="w-full h-full bg-slate-100 rounded-xl flex items-center justify-center text-3xl">
                    🏸
                  </div>
                </div>
                <div className="text-white mb-1">
                  <h1 className="text-2xl md:text-3xl font-bold">{community.name}</h1>
                  <div className="flex items-center text-sm opacity-90">
                    <MapPin className="w-3 h-3 mr-1" /> {community.location} • {community.members} Anggota
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="p-6 pt-8">
            <div className="flex gap-3 mb-6">
              <Button className="bg-brand-gradient flex-1 md:flex-none" onClick={handleJoin}>
                Gabung Komunitas
              </Button>
              <Button variant="outline" className="flex-1 md:flex-none">
                Lihat Member
              </Button>
            </div>

            <Tabs defaultValue="about">
              <TabsList className="w-full justify-start border-b rounded-none bg-transparent p-0 h-auto mb-6">
                <TabsTrigger value="about" className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:shadow-none px-4 py-2">
                  Tentang
                </TabsTrigger>
                <TabsTrigger value="events" className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:shadow-none px-4 py-2">
                  Event & Jadwal
                </TabsTrigger>
                <TabsTrigger value="gallery" className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:shadow-none px-4 py-2">
                  Galeri
                </TabsTrigger>
              </TabsList>

              <TabsContent value="about" className="space-y-4">
                <div className="prose dark:prose-invert max-w-none">
                  <p className="text-muted-foreground leading-relaxed">
                    {community.description}
                  </p>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
                  <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-xl border">
                    <div className="text-sm text-muted-foreground mb-1">Jadwal Rutin</div>
                    <div className="font-semibold">Selasa & Jumat</div>
                    <div className="text-xs text-slate-500">19:00 - 23:00 WIB</div>
                  </div>
                  <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-xl border">
                    <div className="text-sm text-muted-foreground mb-1">Level</div>
                    <div className="font-semibold">Semua Level</div>
                    <div className="text-xs text-slate-500">Beginner welcome!</div>
                  </div>
                  <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-xl border">
                    <div className="text-sm text-muted-foreground mb-1">Iuran</div>
                    <div className="font-semibold">Rp 30.000</div>
                    <div className="text-xs text-slate-500">Per kedatangan</div>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="events">
                <div className="border rounded-xl p-4 hover:bg-slate-50 transition-colors cursor-pointer flex items-center gap-4">
                  <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center text-yellow-600">
                    <Trophy className="w-6 h-6" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold">{community.nextEvent.title}</h3>
                    <div className="text-sm text-muted-foreground flex items-center gap-3 mt-1">
                      <span className="flex items-center"><Calendar className="w-3 h-3 mr-1" /> {community.nextEvent.date}</span>
                      <span className="flex items-center"><MapPin className="w-3 h-3 mr-1" /> {community.nextEvent.location}</span>
                    </div>
                  </div>
                  <Button size="sm" variant="outline">Detail</Button>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  );
}
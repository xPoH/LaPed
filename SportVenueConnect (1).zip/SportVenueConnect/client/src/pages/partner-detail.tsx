import { useRoute, Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  MapPin, 
  Globe, 
  Phone, 
  Mail, 
  ChevronLeft,
  CheckCircle2
} from "lucide-react";
import { toast } from "@/hooks/use-toast";

export default function PartnerDetail() {
  const [, params] = useRoute("/partner/:id");

  // Mock Data
  const partner = {
    id: params?.id,
    name: "Adidas Indonesia",
    type: "Sportswear Brand",
    description: "Mitra resmi penyedia perlengkapan olahraga berkualitas tinggi. Dapatkan diskon khusus member LaPed di seluruh outlet Adidas Indonesia.",
    benefits: [
      "Diskon 15% All Items untuk Member Premium",
      "Akses Event Eksklusif Adidas",
      "Free Custom Jersey untuk Turnamen Komunitas"
    ],
    contact: {
      website: "www.adidas.co.id",
      email: "partnership@adidas.co.id",
      phone: "+62 21 555 1234"
    }
  };

  const handleRedeem = () => {
    toast({
      title: "Voucher Diklaim!",
      description: "Kode promo telah dikirim ke email anda.",
    });
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 pb-20 pt-6">
      <div className="container mx-auto px-4 max-w-3xl">
        <Link href="/">
          <Button variant="ghost" size="sm" className="mb-4 pl-0 hover:bg-transparent hover:text-primary">
            <ChevronLeft className="w-4 h-4 mr-2" /> Kembali ke Beranda
          </Button>
        </Link>

        <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-sm border overflow-hidden">
          <div className="h-40 bg-slate-900 flex items-center justify-center">
             <h1 className="text-4xl font-bold text-white tracking-widest uppercase italic">ADIDAS</h1>
          </div>
          
          <div className="p-8">
            <div className="flex justify-between items-start mb-6">
              <div>
                <Badge className="mb-2 bg-slate-100 text-slate-800 border-slate-200 hover:bg-slate-200">{partner.type}</Badge>
                <h1 className="text-3xl font-bold text-slate-900 dark:text-white">{partner.name}</h1>
                <p className="text-muted-foreground mt-2 text-lg">
                  {partner.description}
                </p>
              </div>
            </div>

            <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-100 dark:border-blue-800 rounded-xl p-6 mb-8">
              <h3 className="font-bold text-lg mb-4 flex items-center text-blue-900 dark:text-blue-100">
                Benefit Khusus Member LaPed
              </h3>
              <ul className="space-y-3">
                {partner.benefits.map((benefit, i) => (
                  <li key={i} className="flex items-start gap-3 text-slate-700 dark:text-slate-300">
                    <CheckCircle2 className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
                    {benefit}
                  </li>
                ))}
              </ul>
              <Button className="w-full mt-6 bg-blue-600 hover:bg-blue-700 text-white" onClick={handleRedeem}>
                Klaim Benefit Sekarang
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 border-t pt-6">
              <a href="#" className="flex items-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors">
                <Globe className="w-4 h-4" /> {partner.contact.website}
              </a>
              <a href="#" className="flex items-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors">
                <Mail className="w-4 h-4" /> {partner.contact.email}
              </a>
              <a href="#" className="flex items-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors">
                <Phone className="w-4 h-4" /> {partner.contact.phone}
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
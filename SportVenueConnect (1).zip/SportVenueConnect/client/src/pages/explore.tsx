import { useState } from "react";
import { VenueCard } from "@/components/venue/venue-card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, SlidersHorizontal, Map as MapIcon, List, FilterX } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

import venueFutsal from "@assets/generated_images/modern_indoor_futsal_court_empty.png";
import venueBadminton from "@assets/generated_images/indoor_badminton_court_empty.png";
import venueBasketball from "@assets/generated_images/urban_basketball_court_at_twilight.png";

// Mock Data
const allVenues = [
  { id: 1, title: "Arena Futsal Champions", location: "Kemang, Jakarta Selatan", price: "Rp 150.000", rating: 4.8, reviews: 120, image: venueFutsal, type: "Futsal" },
  { id: 2, title: "GOR Badminton Sejahtera", location: "Tebet, Jakarta Selatan", price: "Rp 80.000", rating: 4.5, reviews: 85, image: venueBadminton, type: "Badminton" },
  { id: 3, title: "Skyline Basketball Court", location: "Senayan, Jakarta Pusat", price: "Rp 200.000", rating: 4.9, reviews: 210, image: venueBasketball, type: "Basket" },
  { id: 4, title: "Mega Futsal Center", location: "Cilandak, Jakarta Selatan", price: "Rp 130.000", rating: 4.4, reviews: 65, image: venueFutsal, type: "Futsal" },
  { id: 5, title: "Tennis Club Elite", location: "Menteng, Jakarta Pusat", price: "Rp 250.000", rating: 4.7, reviews: 90, image: venueBasketball, type: "Tenis" },
  { id: 6, title: "Mini Soccer Galaxy", location: "BSD, Tangerang", price: "Rp 350.000", rating: 4.6, reviews: 45, image: venueFutsal, type: "Mini Soccer" },
];

const categories = ['Semua', 'Futsal', 'Badminton', 'Basket', 'Tenis', 'Mini Soccer'];

export default function Explore() {
  const [viewMode, setViewMode] = useState<'list' | 'map'>('list');
  const [selectedCategory, setSelectedCategory] = useState('Semua');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredVenues = allVenues.filter(venue => {
    const matchesCategory = selectedCategory === 'Semua' || venue.type === selectedCategory;
    const matchesSearch = venue.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          venue.location.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 pt-6 pb-20">
      <div className="container mx-auto px-4">
        
        {/* Header Filter */}
        <div className="flex flex-col md:flex-row gap-4 justify-between items-start md:items-center mb-8">
          <div>
            <h1 className="text-3xl font-heading font-bold text-slate-900 dark:text-white">Jelajah Lapangan</h1>
            <p className="text-muted-foreground">Temukan venue olahraga terbaik di sekitarmu</p>
          </div>
          
          <div className="flex items-center bg-white dark:bg-slate-900 p-1 rounded-lg border shadow-sm">
            <Button 
              variant={viewMode === 'list' ? 'secondary' : 'ghost'} 
              size="sm" 
              onClick={() => setViewMode('list')}
              className="gap-2"
            >
              <List className="w-4 h-4" /> List
            </Button>
            <Button 
              variant={viewMode === 'map' ? 'secondary' : 'ghost'} 
              size="sm" 
              onClick={() => setViewMode('map')}
              className="gap-2"
            >
              <MapIcon className="w-4 h-4" /> Peta
            </Button>
          </div>
        </div>

        {/* Search & Filter Bar */}
        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border shadow-sm mb-8 sticky top-20 z-30 transition-all duration-300">
          <div className="flex gap-3 flex-col md:flex-row">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input 
                placeholder="Cari nama lapangan atau daerah..." 
                className="pl-9 bg-slate-50 border-slate-200"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <Button variant="outline" className="gap-2 border-slate-200 hidden md:flex">
              <SlidersHorizontal className="w-4 h-4" /> Filter Lanjutan
            </Button>
          </div>
          
          <div className="flex gap-2 mt-4 overflow-x-auto pb-2 scrollbar-hide">
            {categories.map((cat) => (
              <Button 
                key={cat} 
                variant={selectedCategory === cat ? "default" : "outline"} 
                size="sm" 
                onClick={() => setSelectedCategory(cat)}
                className={`rounded-full transition-all duration-300 ${selectedCategory === cat ? 'shadow-md scale-105' : 'hover:bg-slate-100'}`}
              >
                {cat}
              </Button>
            ))}
          </div>
        </div>

        {/* Content */}
        <AnimatePresence mode="wait">
          {filteredVenues.length > 0 ? (
            <motion.div 
              layout
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
            >
              {filteredVenues.map((venue, i) => (
                <VenueCard 
                  key={venue.id}
                  index={i}
                  {...venue}
                  features={["wifi", "parking"]}
                />
              ))}
            </motion.div>
          ) : (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-center py-20"
            >
              <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <FilterX className="w-8 h-8 text-slate-400" />
              </div>
              <h3 className="text-xl font-bold text-slate-900">Tidak ada lapangan ditemukan</h3>
              <p className="text-muted-foreground mt-2">Coba ubah filter atau kata kuncimu.</p>
              <Button 
                variant="link" 
                onClick={() => {setSelectedCategory('Semua'); setSearchQuery('');}}
                className="mt-4 text-primary"
              >
                Reset Filter
              </Button>
            </motion.div>
          )}
        </AnimatePresence>

        {filteredVenues.length > 0 && (
          <div className="mt-12 text-center">
            <Button variant="outline" size="lg" className="hover:bg-slate-100 transition-colors">
              Muat Lebih Banyak
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
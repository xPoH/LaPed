import { useRoute, Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  MapPin, 
  Calendar, 
  Clock, 
  Users, 
  Trophy, 
  ChevronLeft, 
  Share2,
  MessageCircle
} from "lucide-react";
import { toast } from "@/hooks/use-toast";

export default function SparringDetail() {
  const [, params] = useRoute("/sparring/:id");
  
  // Mock Data
  const match = {
    id: params?.id,
    teamName: "FC Barcelona Fans Indo",
    sport: "Futsal",
    level: "Intermediate",
    date: "Sabtu, 12 Oktober 2024",
    time: "19:00 - 21:00 WIB",
    location: "Arena Futsal Champions",
    price: "Rp 25.000 / orang",
    needed: 2,
    description: "Mencari 2 orang pemain tambahan untuk fun game rutin mingguan. Level permainan intermediate, santai tapi serius. Usia rata-rata 20-25 tahun.",
    host: {
      name: "Budi Santoso",
      avatar: "BS",
      role: "Kapten Tim"
    },
    members: [1, 2, 3, 4, 5, 6, 7, 8]
  };

  const handleJoin = () => {
    toast({
      title: "Request Terkirim! 🚀",
      description: "Kapten tim akan segera mengkonfirmasi permintaan bergabungmu.",
    });
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 pb-20 pt-6">
      <div className="container mx-auto px-4 max-w-3xl">
        <Link href="/community">
          <Button variant="ghost" size="sm" className="mb-4 pl-0 hover:bg-transparent hover:text-primary">
            <ChevronLeft className="w-4 h-4 mr-2" /> Kembali ke Komunitas
          </Button>
        </Link>

        <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-sm border overflow-hidden">
          {/* Header */}
          <div className="h-32 bg-gradient-to-r from-blue-600 to-purple-600 relative">
            <div className="absolute -bottom-10 left-6">
              <div className="w-24 h-24 rounded-2xl bg-white p-1 shadow-lg">
                <div className="w-full h-full bg-slate-100 rounded-xl flex items-center justify-center text-4xl">
                  ⚽
                </div>
              </div>
            </div>
          </div>

          <div className="pt-12 px-6 pb-6">
            <div className="flex justify-between items-start mb-4">
              <div>
                <div className="flex gap-2 mb-2">
                  <Badge className="bg-blue-100 text-blue-700 hover:bg-blue-200 border-none">{match.sport}</Badge>
                  <Badge variant="outline" className="border-orange-200 text-orange-700 bg-orange-50">{match.level}</Badge>
                </div>
                <h1 className="text-2xl md:text-3xl font-heading font-bold text-slate-900 dark:text-white mb-1">
                  {match.teamName}
                </h1>
                <p className="text-muted-foreground flex items-center text-sm">
                  Dibuat oleh <span className="font-semibold text-slate-900 dark:text-white ml-1">{match.host.name}</span>
                </p>
              </div>
              <Button variant="outline" size="icon" className="rounded-full">
                <Share2 className="w-4 h-4" />
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8">
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center shrink-0">
                    <Calendar className="w-5 h-5 text-slate-600" />
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground">Tanggal</div>
                    <div className="font-semibold">{match.date}</div>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center shrink-0">
                    <Clock className="w-5 h-5 text-slate-600" />
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground">Waktu</div>
                    <div className="font-semibold">{match.time}</div>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center shrink-0">
                    <MapPin className="w-5 h-5 text-slate-600" />
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground">Lokasi</div>
                    <div className="font-semibold text-primary cursor-pointer hover:underline">{match.location}</div>
                  </div>
                </div>
              </div>

              <div className="bg-slate-50 dark:bg-slate-800 p-5 rounded-xl">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="font-bold">Slot Pemain</h3>
                  <Badge variant="secondary" className="bg-green-100 text-green-700">
                    Butuh {match.needed} lagi
                  </Badge>
                </div>
                
                <div className="flex flex-wrap gap-2 mb-6">
                  {match.members.map((m) => (
                    <div key={m} className="w-8 h-8 rounded-full bg-slate-200 border-2 border-white flex items-center justify-center text-xs font-bold text-slate-500">
                      P{m}
                    </div>
                  ))}
                  {[...Array(match.needed)].map((_, i) => (
                    <div key={i} className="w-8 h-8 rounded-full border-2 border-dashed border-slate-300 flex items-center justify-center text-xs text-slate-400 bg-white">
                      ?
                    </div>
                  ))}
                </div>

                <div className="space-y-3">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Biaya Patungan</span>
                    <span className="font-bold">{match.price}</span>
                  </div>
                  <Button className="w-full bg-brand-gradient" onClick={handleJoin}>
                    Join Sparing
                  </Button>
                  <Button variant="outline" className="w-full">
                    <MessageCircle className="w-4 h-4 mr-2" /> Chat Kapten
                  </Button>
                </div>
              </div>
            </div>

            <div className="mt-8 pt-6 border-t">
              <h3 className="font-bold mb-3">Deskripsi</h3>
              <p className="text-muted-foreground leading-relaxed">
                {match.description}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
import { useState } from "react";
import { useRoute } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Calendar } from "@/components/ui/calendar";
import { 
  MapPin, 
  Star, 
  Wifi, 
  Car, 
  Utensils, 
  Share2, 
  Heart,
  Clock,
  CheckCircle2,
  ChevronLeft
} from "lucide-react";
import { Link } from "wouter";
import { toast } from "@/hooks/use-toast";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter
} from "@/components/ui/dialog";

import venueFutsal from "@assets/generated_images/modern_indoor_futsal_court_empty.png";

export default function VenueDetail() {
  const [, params] = useRoute("/venue/:id");
  const [date, setDate] = useState<Date | undefined>(new Date());
  const [selectedTime, setSelectedTime] = useState<string | null>(null);
  const [isFavorite, setIsFavorite] = useState(false);

  // Mock Data based on ID (in a real app this would fetch)
  const venue = {
    title: "Arena Futsal Champions",
    location: "Jl. Kemang Raya No. 12, Jakarta Selatan",
    price: "Rp 150.000",
    rating: 4.8,
    reviews: 128,
    description: "Arena futsal standar internasional dengan rumput sintetis kualitas terbaik. Dilengkapi dengan pencahayaan LED terang, tribun penonton, dan fasilitas shower air panas. Cocok untuk turnamen maupun latihan rutin.",
    features: ["Wifi Kencang", "Parkir Luas", "Kantin", "Musholla", "Loker", "Shower Air Panas"],
    images: [venueFutsal, venueFutsal, venueFutsal]
  };

  const timeSlots = [
    "08:00", "09:00", "10:00", "11:00", "13:00", "14:00", 
    "15:00", "16:00", "17:00", "19:00", "20:00", "21:00"
  ];

  const handleBooking = () => {
    toast({
      title: "Booking Berhasil! 🎉",
      description: `Anda telah membooking lapangan untuk tanggal ${date?.toLocaleDateString()} jam ${selectedTime}.`,
      variant: "default",
    });
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 pb-20">
      {/* Header Image */}
      <div className="relative h-[300px] md:h-[400px] w-full">
        <img 
          src={venue.images[0]} 
          alt={venue.title} 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 to-transparent" />
        
        <div className="absolute top-4 left-4 md:top-8 md:left-8 z-10">
          <Link href="/explore">
            <Button variant="secondary" size="sm" className="gap-2 rounded-full bg-white/20 backdrop-blur-md hover:bg-white/40 text-white border-none">
              <ChevronLeft className="w-4 h-4" /> Kembali
            </Button>
          </Link>
        </div>

        <div className="absolute bottom-0 left-0 right-0 p-4 md:p-8 container mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-end gap-4">
            <div>
              <Badge className="mb-2 bg-primary text-white border-none">Futsal</Badge>
              <h1 className="text-3xl md:text-5xl font-heading font-bold text-white mb-2">{venue.title}</h1>
              <div className="flex items-center text-gray-200 text-sm md:text-base">
                <MapPin className="w-4 h-4 mr-1 text-primary" />
                {venue.location}
              </div>
            </div>
            <div className="flex gap-2">
              <Button 
                size="icon" 
                variant="outline" 
                className="rounded-full bg-white/10 border-white/20 text-white hover:bg-white/20"
                onClick={() => setIsFavorite(!isFavorite)}
              >
                <Heart className={`w-5 h-5 ${isFavorite ? 'fill-red-500 text-red-500' : ''}`} />
              </Button>
              <Button size="icon" variant="outline" className="rounded-full bg-white/10 border-white/20 text-white hover:bg-white/20">
                <Share2 className="w-5 h-5" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 mt-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Stats */}
            <div className="flex gap-6 p-4 bg-white dark:bg-slate-900 rounded-xl border shadow-sm">
              <div className="text-center px-4 border-r">
                <div className="text-2xl font-bold text-slate-900 dark:text-white flex items-center justify-center gap-1">
                  4.8 <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                </div>
                <div className="text-xs text-muted-foreground">Rating</div>
              </div>
              <div className="text-center px-4 border-r">
                <div className="text-2xl font-bold text-slate-900 dark:text-white">128</div>
                <div className="text-xs text-muted-foreground">Review</div>
              </div>
              <div className="text-center px-4">
                <div className="text-2xl font-bold text-slate-900 dark:text-white">24 Jam</div>
                <div className="text-xs text-muted-foreground">Operasional</div>
              </div>
            </div>

            {/* Description */}
            <div>
              <h2 className="text-xl font-bold font-heading mb-3">Tentang Venue</h2>
              <p className="text-muted-foreground leading-relaxed">
                {venue.description}
              </p>
            </div>

            {/* Facilities */}
            <div>
              <h2 className="text-xl font-bold font-heading mb-4">Fasilitas</h2>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {venue.features.map((feature, i) => (
                  <div key={i} className="flex items-center gap-2 p-3 rounded-lg bg-slate-100 dark:bg-slate-800 text-sm font-medium">
                    <CheckCircle2 className="w-4 h-4 text-primary" />
                    {feature}
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Booking Sidebar */}
          <div className="lg:col-span-1">
            <div className="sticky top-24 bg-white dark:bg-slate-900 p-6 rounded-2xl border shadow-lg">
              <h3 className="text-lg font-bold mb-4">Jadwal Booking</h3>
              
              <div className="mb-6">
                <div className="text-sm font-medium mb-2 text-muted-foreground">Pilih Tanggal</div>
                <div className="p-3 border rounded-xl bg-slate-50 dark:bg-slate-800 flex items-center justify-center">
                  <Calendar
                    mode="single"
                    selected={date}
                    onSelect={setDate}
                    className="rounded-md border shadow bg-white dark:bg-slate-900"
                  />
                </div>
              </div>

              <div className="mb-6">
                <div className="text-sm font-medium mb-2 text-muted-foreground">Pilih Jam (Durasi 1 Jam)</div>
                <div className="grid grid-cols-3 gap-2">
                  {timeSlots.map((time) => (
                    <button
                      key={time}
                      onClick={() => setSelectedTime(time)}
                      className={`py-2 px-1 rounded-lg text-sm font-medium transition-all ${
                        selectedTime === time 
                          ? 'bg-primary text-white shadow-md scale-105' 
                          : 'bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300'
                      }`}
                    >
                      {time}
                    </button>
                  ))}
                </div>
              </div>

              <div className="border-t pt-4 mb-6">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-muted-foreground">Harga Sewa</span>
                  <span className="font-bold text-lg">{venue.price}</span>
                </div>
                {selectedTime && (
                  <div className="flex justify-between items-center text-primary text-sm">
                    <span>Jadwal Dipilih</span>
                    <span className="font-semibold">{date?.toLocaleDateString('id-ID', { day: 'numeric', month: 'short' })}, {selectedTime}</span>
                  </div>
                )}
              </div>

              <Dialog>
                <DialogTrigger asChild>
                  <Button className="w-full h-12 text-lg font-bold bg-slate-900 text-white hover:bg-slate-800" disabled={!selectedTime}>
                    Booking Sekarang
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Konfirmasi Booking</DialogTitle>
                    <DialogDescription>
                      Cek kembali detail pesanan anda sebelum melanjutkan pembayaran.
                    </DialogDescription>
                  </DialogHeader>
                  
                  <div className="bg-slate-50 p-4 rounded-lg space-y-3">
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Venue</span>
                      <span className="font-medium text-right">{venue.title}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Waktu</span>
                      <span className="font-medium">{date?.toLocaleDateString('id-ID', { weekday: 'long', day: 'numeric', month: 'long' })}, {selectedTime}</span>
                    </div>
                    <div className="flex justify-between border-t pt-2">
                      <span className="font-bold">Total Bayar</span>
                      <span className="font-bold text-primary text-lg">{venue.price}</span>
                    </div>
                  </div>

                  <DialogFooter>
                    <Button onClick={handleBooking} className="w-full bg-brand-gradient">
                      Bayar & Konfirmasi
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}